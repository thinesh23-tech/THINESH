"use client"

import { useRef, useState, useCallback, useEffect } from "react"
import { Mic, MicOff, Volume2, Languages, Trash2, MessageSquare, Settings2, ChevronDown } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { useToast } from "@/hooks/use-toast"
import type { Dialogue } from "@/lib/types"
import type { SpeechRecognition } from "web-speech-api"

interface AudioRecorderProps {
  enabled: boolean
  onToggle: (enabled: boolean) => void
  onTranscription: (text: string, options?: Partial<Dialogue>) => void
  isRecording: boolean
  setIsRecording: (value: boolean) => void
}

const LANGUAGES = [
  { code: "en-US", name: "English (US)" },
  { code: "en-GB", name: "English (UK)" },
  { code: "es-ES", name: "Spanish" },
  { code: "fr-FR", name: "French" },
  { code: "de-DE", name: "German" },
  { code: "ja-JP", name: "Japanese" },
  { code: "ko-KR", name: "Korean" },
  { code: "zh-CN", name: "Chinese" },
]

const BUBBLE_STYLES = [
  { value: "speech", label: "Speech", icon: "💬" },
  { value: "thought", label: "Thought", icon: "💭" },
  { value: "shout", label: "Shout", icon: "📢" },
  { value: "whisper", label: "Whisper", icon: "🤫" },
  { value: "narration", label: "Narration", icon: "📖" },
] as const

export function AudioRecorder({ enabled, onToggle, onTranscription, isRecording, setIsRecording }: AudioRecorderProps) {
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const [transcript, setTranscript] = useState("")
  const [interimTranscript, setInterimTranscript] = useState("")
  const [audioLevel, setAudioLevel] = useState(0)
  const [dialogueList, setDialogueList] = useState<Array<{ text: string; style: string; character: string }>>([])
  const analyserRef = useRef<AnalyserNode | null>(null)
  const audioContextRef = useRef<AudioContext | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const animationRef = useRef<number>()
  const { toast } = useToast()

  const [language, setLanguage] = useState("en-US")
  const [characterName, setCharacterName] = useState("Hero")
  const [bubbleStyle, setBubbleStyle] = useState<Dialogue["style"]>("speech")
  const [settingsOpen, setSettingsOpen] = useState(false)

  const updateAudioLevel = useCallback(() => {
    if (!analyserRef.current) return
    const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount)
    analyserRef.current.getByteFrequencyData(dataArray)
    const average = dataArray.reduce((a, b) => a + b) / dataArray.length
    setAudioLevel(average / 255)
    animationRef.current = requestAnimationFrame(updateAudioLevel)
  }, [])

  const startRecording = useCallback(async () => {
    try {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      if (!SpeechRecognition) {
        toast({
          title: "Not Supported",
          description: "Speech recognition is not supported. Try Chrome or Edge.",
          variant: "destructive",
        })
        return
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      streamRef.current = stream

      const audioContext = new AudioContext()
      audioContextRef.current = audioContext
      const source = audioContext.createMediaStreamSource(stream)
      const analyser = audioContext.createAnalyser()
      analyser.fftSize = 256
      source.connect(analyser)
      analyserRef.current = analyser

      const recognition = new SpeechRecognition()
      recognition.continuous = true
      recognition.interimResults = true
      recognition.lang = language

      recognition.onresult = (event) => {
        let interim = ""
        let final = ""

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i]
          if (result.isFinal) {
            final += result[0].transcript
          } else {
            interim += result[0].transcript
          }
        }

        if (final) {
          let processed = final.trim()
          processed = processed.charAt(0).toUpperCase() + processed.slice(1)
          if (!/[.!?]$/.test(processed)) {
            const questionWords = [
              "what",
              "why",
              "how",
              "when",
              "where",
              "who",
              "which",
              "is",
              "are",
              "do",
              "does",
              "can",
            ]
            const firstWord = processed.split(" ")[0].toLowerCase()
            processed += questionWords.includes(firstWord) ? "?" : "."
          }
          setTranscript((prev) => (prev ? prev + " " + processed : processed))
        }
        setInterimTranscript(interim)
      }

      recognition.onerror = (event) => {
        if (event.error !== "no-speech") {
          toast({
            title: "Error",
            description: `Recognition error: ${event.error}`,
            variant: "destructive",
          })
        }
      }

      recognition.onend = () => {
        if (isRecording) {
          recognition.start()
        }
      }

      recognitionRef.current = recognition
      recognition.start()
      setIsRecording(true)
      updateAudioLevel()

      toast({
        title: "Recording Started",
        description: `Listening in ${LANGUAGES.find((l) => l.code === language)?.name}...`,
      })
    } catch {
      toast({
        title: "Microphone Error",
        description: "Unable to access microphone. Check permissions.",
        variant: "destructive",
      })
    }
  }, [language, isRecording, setIsRecording, toast, updateAudioLevel])

  const stopRecording = useCallback(() => {
    recognitionRef.current?.stop()
    recognitionRef.current = null
    streamRef.current?.getTracks().forEach((track) => track.stop())
    streamRef.current = null
    audioContextRef.current?.close()
    audioContextRef.current = null
    if (animationRef.current) cancelAnimationFrame(animationRef.current)
    setIsRecording(false)
    setInterimTranscript("")
    setAudioLevel(0)
  }, [setIsRecording])

  const addDialogueToPanel = () => {
    if (transcript.trim()) {
      // Add to local dialogue list for display
      setDialogueList((prev) => [...prev, { text: transcript, style: bubbleStyle, character: characterName }])
      // Send to parent component
      onTranscription(transcript, {
        style: bubbleStyle,
        character: characterName,
      })
      setTranscript("")
      setInterimTranscript("")
      toast({
        title: "Dialogue Added",
        description: `"${transcript.slice(0, 30)}..." added to comic panel.`,
      })
    }
  }

  const removeDialogue = (index: number) => {
    setDialogueList((prev) => prev.filter((_, i) => i !== index))
  }

  useEffect(() => {
    return () => {
      stopRecording()
    }
  }, [stopRecording])

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-primary" />
            Voice to Dialogue
          </CardTitle>
          <div className="flex items-center gap-2">
            <Switch checked={enabled} onCheckedChange={onToggle} id="audio-toggle" />
            <Label htmlFor="audio-toggle" className="text-xs text-muted-foreground">
              {enabled ? "On" : "Off"}
            </Label>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        {enabled ? (
          <div className="space-y-6">
            {/* Main Recording Button */}
            <div className="flex flex-col items-center gap-4">
              <button
                onClick={isRecording ? stopRecording : startRecording}
                className={`relative w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300 ${
                  isRecording
                    ? "bg-destructive hover:bg-destructive/90 shadow-lg shadow-destructive/30"
                    : "bg-primary hover:bg-primary/90 shadow-lg shadow-primary/30"
                }`}
              >
                {isRecording ? <MicOff className="w-10 h-10 text-white" /> : <Mic className="w-10 h-10 text-white" />}
                {isRecording && (
                  <span className="absolute inset-0 rounded-full border-4 border-destructive animate-ping opacity-30" />
                )}
              </button>
              <div className="text-center">
                <p className="text-sm font-medium">
                  {isRecording ? "Recording... Click to stop" : "Click to start recording"}
                </p>
                {isRecording && (
                  <Badge variant="destructive" className="mt-2">
                    <span className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse" />
                    Live
                  </Badge>
                )}
              </div>
            </div>

            {/* Audio Visualizer */}
            {isRecording && (
              <div className="h-16 bg-secondary rounded-xl overflow-hidden flex items-center justify-center gap-1 px-6">
                {Array.from({ length: 40 }).map((_, i) => (
                  <div
                    key={i}
                    className="w-1.5 bg-gradient-to-t from-primary to-primary/40 rounded-full transition-all duration-75"
                    style={{
                      height: `${Math.max(12, audioLevel * 100 * (0.5 + Math.sin(i * 0.3 + Date.now() * 0.005) * 0.5))}%`,
                    }}
                  />
                ))}
              </div>
            )}

            {/* Interim Transcript (what's being spoken right now) */}
            {interimTranscript && (
              <div className="p-4 bg-primary/10 rounded-xl border-2 border-dashed border-primary/30">
                <p className="text-sm text-primary italic animate-pulse">{interimTranscript}...</p>
              </div>
            )}

            {/* Settings Collapsible */}
            <Collapsible open={settingsOpen} onOpenChange={setSettingsOpen}>
              <CollapsibleTrigger asChild>
                <Button variant="outline" className="w-full justify-between bg-transparent">
                  <span className="flex items-center gap-2">
                    <Settings2 className="w-4 h-4" />
                    Settings
                  </span>
                  <ChevronDown className={`w-4 h-4 transition-transform ${settingsOpen ? "rotate-180" : ""}`} />
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="pt-4 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground flex items-center gap-1">
                      <Languages className="w-3 h-3" /> Language
                    </Label>
                    <Select value={language} onValueChange={setLanguage}>
                      <SelectTrigger className="bg-secondary">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {LANGUAGES.map((lang) => (
                          <SelectItem key={lang.code} value={lang.code}>
                            {lang.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground">Character Name</Label>
                    <input
                      type="text"
                      value={characterName}
                      onChange={(e) => setCharacterName(e.target.value)}
                      className="w-full px-3 py-2 rounded-md bg-secondary border border-border text-sm"
                      placeholder="Enter name..."
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Bubble Style</Label>
                  <div className="grid grid-cols-5 gap-2">
                    {BUBBLE_STYLES.map((style) => (
                      <button
                        key={style.value}
                        onClick={() => setBubbleStyle(style.value as Dialogue["style"])}
                        className={`p-3 rounded-lg text-center transition-all ${
                          bubbleStyle === style.value
                            ? "bg-primary text-primary-foreground"
                            : "bg-secondary hover:bg-secondary/80"
                        }`}
                      >
                        <span className="text-lg block">{style.icon}</span>
                        <span className="text-xs">{style.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>

            {/* Transcript Editor */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-medium flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  Dialogue Text
                </Label>
                {transcript && (
                  <Button variant="ghost" size="sm" onClick={() => setTranscript("")}>
                    <Trash2 className="w-3 h-3 mr-1" />
                    Clear
                  </Button>
                )}
              </div>
              <Textarea
                placeholder="Speak into your microphone or type dialogue here..."
                value={transcript}
                onChange={(e) => setTranscript(e.target.value)}
                className="min-h-[120px] bg-secondary border-border resize-none text-base leading-relaxed"
              />
              <Button
                onClick={addDialogueToPanel}
                disabled={!transcript.trim()}
                className="w-full h-12 text-base font-medium"
              >
                <MessageSquare className="w-5 h-5 mr-2" />
                Add Dialogue to Comic Panel
              </Button>
            </div>

            {/* Dialogue List */}
            {dialogueList.length > 0 && (
              <div className="space-y-3">
                <Label className="text-sm font-medium">Added Dialogues ({dialogueList.length})</Label>
                <div className="space-y-2 max-h-[200px] overflow-y-auto pr-2">
                  {dialogueList.map((dialogue, index) => (
                    <div
                      key={index}
                      className="p-4 bg-secondary rounded-xl border border-border flex items-start justify-between gap-3"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline" className="text-xs">
                            {dialogue.character}
                          </Badge>
                          <Badge variant="secondary" className="text-xs capitalize">
                            {dialogue.style}
                          </Badge>
                        </div>
                        <p className="text-sm text-foreground leading-relaxed">{dialogue.text}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="shrink-0 text-muted-foreground hover:text-destructive"
                        onClick={() => removeDialogue(index)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-10">
            <div className="w-20 h-20 mx-auto rounded-full bg-secondary flex items-center justify-center mb-4">
              <Mic className="w-10 h-10 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground font-medium">Voice Recording Disabled</p>
            <p className="text-sm text-muted-foreground mt-1">Enable to add dialogues by speaking</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

declare global {
  interface Window {
    SpeechRecognition: typeof SpeechRecognition
    webkitSpeechRecognition: typeof SpeechRecognition
  }
}
