"use client"

import type React from "react"

import { useState } from "react"
import { Trash2, MessageSquare, Sparkles, GripVertical } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { ComicPanel, ComicStyle } from "@/lib/types"
import { cn } from "@/lib/utils"
import { DialogueEditor } from "./dialogue-editor"
import { EffectsPanel } from "./effects-panel"

interface ComicPanelGridProps {
  panels: ComicPanel[]
  currentStyle: ComicStyle
  onUpdatePanel: (panelId: string, updates: Partial<ComicPanel>) => void
  onDeletePanel: (panelId: string) => void
  onReorderPanels: (startIndex: number, endIndex: number) => void
  layout: "grid" | "strip" | "manga"
}

export function ComicPanelGrid({
  panels,
  currentStyle,
  onUpdatePanel,
  onDeletePanel,
  onReorderPanels,
  layout,
}: ComicPanelGridProps) {
  const [selectedPanel, setSelectedPanel] = useState<string | null>(null)
  const [editingDialogue, setEditingDialogue] = useState<string | null>(null)
  const [showEffects, setShowEffects] = useState<string | null>(null)
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null)

  const handleDragStart = (index: number) => {
    setDraggedIndex(index)
  }

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault()
    if (draggedIndex !== null && draggedIndex !== index) {
      onReorderPanels(draggedIndex, index)
      setDraggedIndex(index)
    }
  }

  const handleDragEnd = () => {
    setDraggedIndex(null)
  }

  const getLayoutClasses = () => {
    switch (layout) {
      case "strip":
        return "grid-cols-1 md:grid-cols-2"
      case "manga":
        return "grid-cols-2 md:grid-cols-3"
      default:
        return "grid-cols-2 lg:grid-cols-3"
    }
  }

  if (panels.length === 0) {
    return (
      <Card className="border-border bg-card">
        <CardContent className="py-12">
          <div className="text-center space-y-4">
            <div className="w-20 h-20 mx-auto rounded-2xl bg-muted flex items-center justify-center">
              <Sparkles className="w-10 h-10 text-muted-foreground" />
            </div>
            <div>
              <h3 className="text-lg font-medium">No panels yet</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Start capturing frames from your video to create comic panels
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            Comic Panels
            <Badge variant="secondary">{panels.length}</Badge>
          </CardTitle>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <GripVertical className="w-3 h-3" />
            Drag to reorder
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <div className={cn("grid gap-4", getLayoutClasses())}>
          {panels.map((panel, index) => (
            <div
              key={panel.id}
              draggable
              onDragStart={() => handleDragStart(index)}
              onDragOver={(e) => handleDragOver(e, index)}
              onDragEnd={handleDragEnd}
              className={cn(
                "comic-panel relative group cursor-move transition-all duration-200",
                selectedPanel === panel.id && "ring-2 ring-primary",
                draggedIndex === index && "opacity-50 scale-95",
              )}
              onClick={() => setSelectedPanel(panel.id)}
            >
              {/* Panel number */}
              <div className="absolute -top-2 -left-2 z-10 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center font-bold text-sm shadow-lg">
                {index + 1}
              </div>

              {/* Panel image */}
              <div className="aspect-[4/3] relative overflow-hidden rounded bg-secondary">
                <img
                  src={panel.imageData || "/placeholder.svg"}
                  alt={`Panel ${index + 1}`}
                  className="w-full h-full object-cover"
                />

                {/* Dialogues overlay */}
                {panel.dialogues.map((dialogue) => (
                  <div
                    key={dialogue.id}
                    className={cn(
                      "speech-bubble cursor-pointer hover:scale-105 transition-transform",
                      dialogue.style === "thought" && "rounded-[50%]",
                      dialogue.style === "shout" && "bg-yellow-400",
                    )}
                    style={{
                      left: `${dialogue.position.x}%`,
                      top: `${dialogue.position.y}%`,
                      transform: "translate(-50%, -50%)",
                    }}
                    onClick={(e) => {
                      e.stopPropagation()
                      setEditingDialogue(panel.id)
                    }}
                  >
                    <span className="text-sm font-display">{dialogue.text}</span>
                  </div>
                ))}

                {/* Effects overlay */}
                {panel.effects.map((effect, i) => (
                  <div
                    key={i}
                    className="absolute inset-0 pointer-events-none"
                    style={{ opacity: effect.intensity / 100 }}
                  >
                    {effect.type === "speedlines" && <div className="manga-lines w-full h-full" />}
                    {effect.type === "halftone" && <div className="halftone-overlay w-full h-full" />}
                  </div>
                ))}
              </div>

              {/* Panel controls */}
              <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="flex items-center justify-center gap-1">
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-7 w-7 text-white hover:bg-white/20"
                    onClick={(e) => {
                      e.stopPropagation()
                      setEditingDialogue(panel.id)
                    }}
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-7 w-7 text-white hover:bg-white/20"
                    onClick={(e) => {
                      e.stopPropagation()
                      setShowEffects(panel.id)
                    }}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-7 w-7 text-white hover:bg-white/20"
                    onClick={(e) => {
                      e.stopPropagation()
                      onDeletePanel(panel.id)
                    }}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>

              {/* Style badge */}
              <Badge variant="secondary" className="absolute top-2 right-2 text-[10px] bg-black/50 backdrop-blur-sm">
                {panel.style}
              </Badge>
            </div>
          ))}
        </div>
      </CardContent>

      {/* Dialogue Editor Modal */}
      {editingDialogue && (
        <DialogueEditor
          panel={panels.find((p) => p.id === editingDialogue)!}
          onUpdate={(updates) => onUpdatePanel(editingDialogue, updates)}
          onClose={() => setEditingDialogue(null)}
        />
      )}

      {/* Effects Panel Modal */}
      {showEffects && (
        <EffectsPanel
          panel={panels.find((p) => p.id === showEffects)!}
          onUpdate={(updates) => onUpdatePanel(showEffects, updates)}
          onClose={() => setShowEffects(null)}
        />
      )}
    </Card>
  )
}
