"use client"

import { useState, useCallback } from "react"
import { Download, FileImage, FileText, Film, Loader2 } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import type { ComicPanel, ProjectSettings, ComicStyle } from "@/lib/types"
import { useToast } from "@/hooks/use-toast"

interface ExportPanelProps {
  panels: ComicPanel[]
  settings: ProjectSettings
  currentStyle: ComicStyle
}

export function ExportPanel({ panels, settings, currentStyle }: ExportPanelProps) {
  const [isExporting, setIsExporting] = useState(false)
  const [exportProgress, setExportProgress] = useState(0)
  const [exportFormat, setExportFormat] = useState<"pdf" | "png" | "gif">("png")
  const [quality, setQuality] = useState<"standard" | "high" | "print">("high")
  const { toast } = useToast()

  const generateComicCanvas = useCallback(async (): Promise<HTMLCanvasElement> => {
    const dpi = quality === "print" ? 2 : quality === "high" ? 1.5 : 1
    const panelWidth = Math.round(400 * dpi)
    const panelHeight = Math.round(300 * dpi)
    const padding = Math.round(20 * dpi)
    const borderWidth = Math.round(4 * dpi)

    const cols = settings.panelLayout === "strip" ? panels.length : 2
    const rows = settings.panelLayout === "strip" ? 1 : Math.ceil(panels.length / 2)

    const canvasWidth = cols * panelWidth + (cols + 1) * padding
    const canvasHeight = rows * panelHeight + (rows + 1) * padding + Math.round(60 * dpi)

    const canvas = document.createElement("canvas")
    canvas.width = canvasWidth
    canvas.height = canvasHeight
    const ctx = canvas.getContext("2d")!

    // Background
    ctx.fillStyle = "#1a1a2e"
    ctx.fillRect(0, 0, canvasWidth, canvasHeight)

    // Title
    ctx.fillStyle = "#00d4ff"
    ctx.font = `bold ${Math.round(24 * dpi)}px Arial`
    ctx.textAlign = "center"
    ctx.fillText("ComicForge AI", canvasWidth / 2, Math.round(35 * dpi))

    // Draw panels
    for (let i = 0; i < panels.length; i++) {
      const panel = panels[i]
      const col = settings.panelLayout === "strip" ? i : i % 2
      const row = settings.panelLayout === "strip" ? 0 : Math.floor(i / 2)

      const x = padding + col * (panelWidth + padding)
      const y = Math.round(60 * dpi) + padding + row * (panelHeight + padding)

      // Panel border
      ctx.fillStyle = "#00d4ff"
      ctx.fillRect(x - borderWidth, y - borderWidth, panelWidth + borderWidth * 2, panelHeight + borderWidth * 2)

      // Panel background
      ctx.fillStyle = "#ffffff"
      ctx.fillRect(x, y, panelWidth, panelHeight)

      // Draw image
      if (panel.imageData) {
        try {
          const img = new Image()
          img.crossOrigin = "anonymous"
          await new Promise<void>((resolve, reject) => {
            img.onload = () => resolve()
            img.onerror = reject
            img.src = panel.imageData
          })
          ctx.drawImage(img, x, y, panelWidth, panelHeight)
        } catch (e) {
          ctx.fillStyle = "#333"
          ctx.fillRect(x, y, panelWidth, panelHeight)
        }
      }

      // Draw dialogues
      for (const dialogue of panel.dialogues) {
        const bubbleX = x + (dialogue.position.x / 100) * panelWidth
        const bubbleY = y + (dialogue.position.y / 100) * panelHeight
        const bubbleWidth = Math.min(panelWidth * 0.6, Math.round(180 * dpi))
        const bubbleHeight = Math.round(60 * dpi)

        // Speech bubble
        ctx.fillStyle = "white"
        ctx.strokeStyle = "#000"
        ctx.lineWidth = Math.round(2 * dpi)
        ctx.beginPath()
        ctx.roundRect(bubbleX - bubbleWidth / 2, bubbleY, bubbleWidth, bubbleHeight, Math.round(10 * dpi))
        ctx.fill()
        ctx.stroke()

        // Bubble tail
        ctx.beginPath()
        ctx.moveTo(bubbleX - 10 * dpi, bubbleY + bubbleHeight)
        ctx.lineTo(bubbleX - 20 * dpi, bubbleY + bubbleHeight + 15 * dpi)
        ctx.lineTo(bubbleX + 5 * dpi, bubbleY + bubbleHeight)
        ctx.fillStyle = "white"
        ctx.fill()
        ctx.stroke()

        // Text
        ctx.fillStyle = "#000"
        ctx.font = `${Math.round(12 * dpi)}px Arial`
        ctx.textAlign = "center"
        const words = dialogue.text.split(" ")
        let line = ""
        let lineY = bubbleY + Math.round(20 * dpi)
        for (const word of words) {
          const testLine = line + word + " "
          if (ctx.measureText(testLine).width > bubbleWidth - 20 * dpi) {
            ctx.fillText(line.trim(), bubbleX, lineY)
            line = word + " "
            lineY += Math.round(14 * dpi)
          } else {
            line = testLine
          }
        }
        ctx.fillText(line.trim(), bubbleX, lineY)
      }

      setExportProgress(Math.round(((i + 1) / panels.length) * 80))
    }

    return canvas
  }, [panels, settings, quality])

  const handleExport = async () => {
    if (panels.length === 0) {
      toast({
        title: "No Panels",
        description: "Add some comic panels before exporting.",
        variant: "destructive",
      })
      return
    }

    setIsExporting(true)
    setExportProgress(0)

    try {
      const canvas = await generateComicCanvas()
      setExportProgress(90)

      let blob: Blob
      let filename: string
      let mimeType: string

      if (exportFormat === "png") {
        blob = await new Promise<Blob>((resolve) => {
          canvas.toBlob((b) => resolve(b!), "image/png", 1.0)
        })
        filename = `comic-story-${Date.now()}.png`
        mimeType = "image/png"
      } else if (exportFormat === "gif") {
        // For GIF, we export as PNG since proper GIF encoding requires external libs
        blob = await new Promise<Blob>((resolve) => {
          canvas.toBlob((b) => resolve(b!), "image/png", 1.0)
        })
        filename = `comic-story-${Date.now()}.png`
        mimeType = "image/png"
        toast({
          title: "Note",
          description: "Animated GIF requires additional setup. Exported as PNG instead.",
        })
      } else {
        // PDF - create a downloadable image wrapped in simple PDF structure
        const dataUrl = canvas.toDataURL("image/png", 1.0)

        // Create a printable HTML page that opens as PDF
        const htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <title>Comic Story</title>
  <style>
    @page { size: auto; margin: 0; }
    body { margin: 0; display: flex; justify-content: center; align-items: center; min-height: 100vh; background: #1a1a2e; }
    img { max-width: 100%; height: auto; }
  </style>
</head>
<body>
  <img src="${dataUrl}" alt="Comic Story" />
</body>
</html>`
        blob = new Blob([htmlContent], { type: "text/html" })
        filename = `comic-story-${Date.now()}.html`
        mimeType = "text/html"
        toast({
          title: "PDF Export",
          description: "Open the HTML file and use Print > Save as PDF for best results.",
        })
      }

      setExportProgress(100)

      // Trigger download
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = filename
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)

      toast({
        title: "Export Complete!",
        description: `Your comic has been downloaded.`,
      })
    } catch (error) {
      console.error("Export error:", error)
      toast({
        title: "Export Failed",
        description: "There was an error exporting your comic. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsExporting(false)
      setExportProgress(0)
    }
  }

  const getEstimatedSize = () => {
    const baseSize = panels.length * (quality === "print" ? 2 : quality === "high" ? 1 : 0.5)
    return `~${baseSize.toFixed(1)} MB`
  }

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Download className="w-5 h-5 text-primary" />
          Export Comic
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="p-4 rounded-lg bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Ready to Export</span>
            <Badge variant="outline" className="text-primary border-primary">
              {panels.length} panels
            </Badge>
          </div>
          <div className="text-xs text-muted-foreground space-y-1">
            <p>
              Style: <span className="text-foreground capitalize">{currentStyle}</span>
            </p>
            <p>
              Layout: <span className="text-foreground capitalize">{settings.panelLayout}</span>
            </p>
            <p>
              Est. Size: <span className="text-foreground">{getEstimatedSize()}</span>
            </p>
          </div>
        </div>

        <Separator />

        <div className="space-y-3">
          <div className="space-y-2">
            <Label className="text-sm">Format</Label>
            <Select value={exportFormat} onValueChange={(v) => setExportFormat(v as typeof exportFormat)}>
              <SelectTrigger className="bg-secondary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="png">
                  <div className="flex items-center gap-2">
                    <FileImage className="w-4 h-4" />
                    PNG Image
                  </div>
                </SelectItem>
                <SelectItem value="pdf">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    PDF (via HTML)
                  </div>
                </SelectItem>
                <SelectItem value="gif">
                  <div className="flex items-center gap-2">
                    <Film className="w-4 h-4" />
                    Animated GIF
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-sm">Quality</Label>
            <Select value={quality} onValueChange={(v) => setQuality(v as typeof quality)}>
              <SelectTrigger className="bg-secondary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="standard">Standard (1x)</SelectItem>
                <SelectItem value="high">High Quality (1.5x)</SelectItem>
                <SelectItem value="print">Print Ready (2x)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {isExporting && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span>Generating comic...</span>
              <span className="text-primary">{exportProgress}%</span>
            </div>
            <Progress value={exportProgress} className="h-2" />
          </div>
        )}

        <Button
          onClick={handleExport}
          disabled={isExporting || panels.length === 0}
          className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90"
          size="lg"
        >
          {isExporting ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Exporting...
            </>
          ) : (
            <>
              <Download className="w-4 h-4 mr-2" />
              Download Comic
            </>
          )}
        </Button>

        <div className="flex flex-wrap gap-1.5 pt-2">
          <Badge variant="secondary" className="text-[10px]">
            Auto Layout
          </Badge>
          <Badge variant="secondary" className="text-[10px]">
            Speech Bubbles
          </Badge>
          <Badge variant="secondary" className="text-[10px]">
            High Resolution
          </Badge>
        </div>
      </CardContent>
    </Card>
  )
}
