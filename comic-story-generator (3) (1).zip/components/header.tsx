"use client"

import { Sparkles, Menu, Github, BookOpen } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full" />
              <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">
                <span className="text-primary">Comic</span>
                <span className="text-foreground">Forge</span>
                <span className="text-accent ml-1">AI</span>
              </h1>
              <p className="text-xs text-muted-foreground hidden sm:block">Real-Time Comic Story Generator</p>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <a href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Features
            </a>
            <a href="#styles" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Styles
            </a>
            <a href="#export" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Export
            </a>
          </nav>

          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="hidden md:flex">
              <BookOpen className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" className="hidden md:flex">
              <Github className="w-4 h-4" />
            </Button>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="bg-card">
                <nav className="flex flex-col gap-4 mt-8">
                  <a href="#features" className="text-lg hover:text-primary transition-colors">
                    Features
                  </a>
                  <a href="#styles" className="text-lg hover:text-primary transition-colors">
                    Styles
                  </a>
                  <a href="#export" className="text-lg hover:text-primary transition-colors">
                    Export
                  </a>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  )
}
