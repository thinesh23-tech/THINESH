"use client"

import type React from "react"

import { useRef, useState, useEffect, useCallback } from "react"
import { Camera, Video, StopCircle, RotateCcw, Upload, Settings2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import type { ComicStyle } from "@/lib/types"
import { applyComicFilter } from "@/lib/comic-filters"
import { useToast } from "@/hooks/use-toast"

interface VideoCaptureProps {
  onCapture: (imageData: string, timestamp: number) => void
  isCapturing: boolean
  setIsCapturing: (value: boolean) => void
  currentStyle: ComicStyle
  autoDetect: boolean
}

export function VideoCapture({ onCapture, isCapturing, setIsCapturing, currentStyle, autoDetect }: VideoCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const previewCanvasRef = useRef<HTMLCanvasElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [videoFile, setVideoFile] = useState<File | null>(null)
  const [sensitivity, setSensitivity] = useState([30])
  const [frameRate, setFrameRate] = useState([2])
  const [lastFrameData, setLastFrameData] = useState<ImageData | null>(null)
  const [sceneChangeCount, setSceneChangeCount] = useState(0)
  const [isLive, setIsLive] = useState(true)
  const { toast } = useToast()

  const startCamera = useCallback(async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: "user",
        },
      })
      setStream(mediaStream)
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream
      }
      setIsLive(true)
      toast({
        title: "Camera Started",
        description: "Your camera is now active and ready to capture.",
      })
    } catch (error) {
      toast({
        title: "Camera Error",
        description: "Unable to access camera. Please check permissions.",
        variant: "destructive",
      })
    }
  }, [toast])

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
      setStream(null)
    }
    setIsCapturing(false)
  }, [stream, setIsCapturing])

  const handleFileUpload = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0]
      if (file && file.type.startsWith("video/")) {
        setVideoFile(file)
        setIsLive(false)
        stopCamera()

        const url = URL.createObjectURL(file)
        if (videoRef.current) {
          videoRef.current.src = url
          videoRef.current.load()
        }

        toast({
          title: "Video Loaded",
          description: `"${file.name}" is ready for comic conversion.`,
        })
      }
    },
    [stopCamera, toast],
  )

  const captureFrame = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return

    const video = videoRef.current
    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = video.videoWidth || 640
    canvas.height = video.videoHeight || 480

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

    // Apply comic filter
    const filteredCanvas = applyComicFilter(canvas, currentStyle)
    const imageData = filteredCanvas.toDataURL("image/png", 0.9)

    onCapture(imageData, video.currentTime)

    toast({
      title: "Frame Captured",
      description: `Panel added with ${currentStyle} style.`,
    })
  }, [currentStyle, onCapture, toast])

  const detectSceneChange = useCallback(
    (currentFrame: ImageData): boolean => {
      if (!lastFrameData) {
        setLastFrameData(currentFrame)
        return true
      }

      let diff = 0
      const len = currentFrame.data.length

      for (let i = 0; i < len; i += 16) {
        diff += Math.abs(currentFrame.data[i] - lastFrameData.data[i])
        diff += Math.abs(currentFrame.data[i + 1] - lastFrameData.data[i + 1])
        diff += Math.abs(currentFrame.data[i + 2] - lastFrameData.data[i + 2])
      }

      const avgDiff = diff / (len / 16) / 3
      setLastFrameData(currentFrame)

      return avgDiff > sensitivity[0]
    },
    [lastFrameData, sensitivity],
  )

  // Auto-capture with scene detection
  useEffect(() => {
    if (!isCapturing || !autoDetect) return

    const interval = setInterval(() => {
      if (!videoRef.current || !canvasRef.current) return

      const video = videoRef.current
      const canvas = canvasRef.current
      const ctx = canvas.getContext("2d")
      if (!ctx) return

      canvas.width = video.videoWidth || 640
      canvas.height = video.videoHeight || 480
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

      const frameData = ctx.getImageData(0, 0, canvas.width, canvas.height)

      if (detectSceneChange(frameData)) {
        setSceneChangeCount((prev) => prev + 1)
        const filteredCanvas = applyComicFilter(canvas, currentStyle)
        onCapture(filteredCanvas.toDataURL("image/png", 0.9), video.currentTime)
      }
    }, 1000 / frameRate[0])

    return () => clearInterval(interval)
  }, [isCapturing, autoDetect, frameRate, currentStyle, onCapture, detectSceneChange])

  // Live preview with filter
  useEffect(() => {
    if (!stream && !videoFile) return

    const updatePreview = () => {
      if (!videoRef.current || !previewCanvasRef.current) return

      const video = videoRef.current
      const canvas = previewCanvasRef.current
      const ctx = canvas.getContext("2d")
      if (!ctx || video.paused || video.ended) return

      canvas.width = video.videoWidth || 640
      canvas.height = video.videoHeight || 480
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

      requestAnimationFrame(updatePreview)
    }

    const video = videoRef.current
    if (video) {
      video.addEventListener("play", updatePreview)
      return () => video.removeEventListener("play", updatePreview)
    }
  }, [stream, videoFile])

  return (
    <Card className="border-border bg-card overflow-hidden">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Video className="w-5 h-5 text-primary" />
              Video Source
            </CardTitle>
            {isCapturing && (
              <Badge variant="destructive" className="recording-pulse">
                <span className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse" />
                Recording
              </Badge>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Settings2 className="w-4 h-4" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80 bg-popover">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-sm">Scene Sensitivity: {sensitivity[0]}</Label>
                    <Slider value={sensitivity} onValueChange={setSensitivity} min={10} max={80} step={5} />
                    <p className="text-xs text-muted-foreground">Higher = fewer captures, Lower = more captures</p>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm">Frame Rate: {frameRate[0]} fps</Label>
                    <Slider value={frameRate} onValueChange={setFrameRate} min={1} max={10} step={1} />
                  </div>

                  <div className="pt-2 border-t border-border">
                    <p className="text-xs text-muted-foreground">
                      Scenes Detected: <span className="text-primary font-bold">{sceneChangeCount}</span>
                    </p>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="relative aspect-video bg-secondary rounded-lg overflow-hidden border border-border">
          <video ref={videoRef} autoPlay playsInline muted={isLive} className="w-full h-full object-cover" />
          <canvas ref={canvasRef} className="hidden" />
          <canvas ref={previewCanvasRef} className="hidden" />

          {!stream && !videoFile && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-secondary/90 backdrop-blur-sm">
              <div className="text-center space-y-4">
                <div className="w-20 h-20 mx-auto rounded-full bg-muted flex items-center justify-center">
                  <Camera className="w-10 h-10 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-foreground font-medium">No video source</p>
                  <p className="text-sm text-muted-foreground">Start camera or upload a video</p>
                </div>
              </div>
            </div>
          )}

          {/* Style indicator overlay */}
          <div className="absolute top-3 left-3">
            <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm">
              {currentStyle.charAt(0).toUpperCase() + currentStyle.slice(1)} Style
            </Badge>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {!stream && !videoFile ? (
            <>
              <Button onClick={startCamera} className="flex-1 sm:flex-none">
                <Camera className="w-4 h-4 mr-2" />
                Start Camera
              </Button>
              <Button variant="outline" onClick={() => fileInputRef.current?.click()} className="flex-1 sm:flex-none">
                <Upload className="w-4 h-4 mr-2" />
                Upload Video
              </Button>
              <input ref={fileInputRef} type="file" accept="video/*" onChange={handleFileUpload} className="hidden" />
            </>
          ) : (
            <>
              <Button onClick={captureFrame} className="flex-1 sm:flex-none bg-primary hover:bg-primary/90">
                <Camera className="w-4 h-4 mr-2" />
                Capture Frame
              </Button>

              <Button
                variant={isCapturing ? "destructive" : "secondary"}
                onClick={() => setIsCapturing(!isCapturing)}
                className="flex-1 sm:flex-none"
              >
                {isCapturing ? (
                  <>
                    <StopCircle className="w-4 h-4 mr-2" />
                    Stop Auto
                  </>
                ) : (
                  <>
                    <Video className="w-4 h-4 mr-2" />
                    Auto Capture
                  </>
                )}
              </Button>

              <Button variant="ghost" size="icon" onClick={stopCamera}>
                <RotateCcw className="w-4 h-4" />
              </Button>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
