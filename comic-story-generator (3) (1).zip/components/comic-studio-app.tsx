"use client"

import { useState, useCallback } from "react"
import { Header } from "./header"
import { VideoCapture } from "./video-capture"
import { ComicStyleSelector } from "./comic-style-selector"
import { ComicPanelGrid } from "./comic-panel-grid"
import { AudioRecorder } from "./audio-recorder"
import { ExportPanel } from "./export-panel"
import { ControlPanel } from "./control-panel"
import type { ComicPanel, ComicStyle, ProjectSettings, Dialogue } from "@/lib/types"
import { Toaster } from "@/components/ui/toaster"

export function ComicStudioApp() {
  const [panels, setPanels] = useState<ComicPanel[]>([])
  const [currentStyle, setCurrentStyle] = useState<ComicStyle>("classic")
  const [isRecording, setIsRecording] = useState(false)
  const [isCapturing, setIsCapturing] = useState(false)
  const [audioEnabled, setAudioEnabled] = useState(false)
  const [settings, setSettings] = useState<ProjectSettings>({
    panelLayout: "grid",
    autoDetectScenes: true,
    speechBubbleStyle: "classic",
    exportQuality: "high",
    pageSize: "a4",
  })

  const handleCaptureFrame = useCallback(
    (imageData: string, timestamp: number) => {
      const newPanel: ComicPanel = {
        id: `panel-${Date.now()}`,
        imageData,
        timestamp,
        style: currentStyle,
        dialogues: [],
        effects: [],
      }
      setPanels((prev) => [...prev, newPanel])
    },
    [currentStyle],
  )

  const handleTranscription = useCallback(
    (text: string, options?: Partial<Dialogue>) => {
      if (panels.length > 0) {
        setPanels((prev) => {
          const updated = [...prev]
          const lastPanel = updated[updated.length - 1]
          lastPanel.dialogues = [
            ...lastPanel.dialogues,
            {
              id: `dialogue-${Date.now()}`,
              text,
              position: { x: 50, y: 20 },
              style: options?.style || "speech",
              character: options?.character,
              emotion: options?.emotion,
            },
          ]
          return updated
        })
      }
    },
    [panels.length],
  )

  const handleUpdatePanel = useCallback((panelId: string, updates: Partial<ComicPanel>) => {
    setPanels((prev) => prev.map((p) => (p.id === panelId ? { ...p, ...updates } : p)))
  }, [])

  const handleDeletePanel = useCallback((panelId: string) => {
    setPanels((prev) => prev.filter((p) => p.id !== panelId))
  }, [])

  const handleReorderPanels = useCallback((startIndex: number, endIndex: number) => {
    setPanels((prev) => {
      const result = Array.from(prev)
      const [removed] = result.splice(startIndex, 1)
      result.splice(endIndex, 0, removed)
      return result
    })
  }, [])

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Sidebar - Controls */}
          <div className="lg:col-span-3 space-y-4">
            <ControlPanel
              settings={settings}
              onSettingsChange={setSettings}
              isCapturing={isCapturing}
              panelCount={panels.length}
            />

            <ComicStyleSelector currentStyle={currentStyle} onStyleChange={setCurrentStyle} />

            <AudioRecorder
              enabled={audioEnabled}
              onToggle={setAudioEnabled}
              onTranscription={handleTranscription}
              isRecording={isRecording}
              setIsRecording={setIsRecording}
            />
          </div>

          {/* Main Content Area */}
          <div className="lg:col-span-6 space-y-4">
            <VideoCapture
              onCapture={handleCaptureFrame}
              isCapturing={isCapturing}
              setIsCapturing={setIsCapturing}
              currentStyle={currentStyle}
              autoDetect={settings.autoDetectScenes}
            />

            <ComicPanelGrid
              panels={panels}
              currentStyle={currentStyle}
              onUpdatePanel={handleUpdatePanel}
              onDeletePanel={handleDeletePanel}
              onReorderPanels={handleReorderPanels}
              layout={settings.panelLayout}
            />
          </div>

          {/* Right Sidebar - Export */}
          <div className="lg:col-span-3">
            <ExportPanel panels={panels} settings={settings} currentStyle={currentStyle} />
          </div>
        </div>
      </main>

      <Toaster />
    </div>
  )
}
