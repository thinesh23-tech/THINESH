"use client"

import { Settings, Layout, BookOpen, Wand2 } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import type { ProjectSettings } from "@/lib/types"

interface ControlPanelProps {
  settings: ProjectSettings
  onSettingsChange: (settings: ProjectSettings) => void
  isCapturing: boolean
  panelCount: number
}

export function ControlPanel({ settings, onSettingsChange, isCapturing, panelCount }: ControlPanelProps) {
  const updateSetting = <K extends keyof ProjectSettings>(key: K, value: ProjectSettings[K]) => {
    onSettingsChange({ ...settings, [key]: value })
  }

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Settings className="w-5 h-5 text-muted-foreground" />
            Project Settings
          </CardTitle>
          {isCapturing && (
            <Badge variant="secondary" className="animate-pulse">
              Auto-capturing
            </Badge>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Stats */}
        <div className="flex items-center justify-between p-3 rounded-lg bg-secondary">
          <span className="text-sm text-muted-foreground">Total Panels</span>
          <span className="text-2xl font-bold text-primary">{panelCount}</span>
        </div>

        <div className="space-y-3">
          <div className="space-y-2">
            <Label className="text-sm flex items-center gap-2">
              <Layout className="w-3.5 h-3.5" />
              Panel Layout
            </Label>
            <Select
              value={settings.panelLayout}
              onValueChange={(v) => updateSetting("panelLayout", v as ProjectSettings["panelLayout"])}
            >
              <SelectTrigger className="bg-secondary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="grid">Grid (Standard)</SelectItem>
                <SelectItem value="strip">Comic Strip</SelectItem>
                <SelectItem value="manga">Manga Style</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-sm flex items-center gap-2">
              <BookOpen className="w-3.5 h-3.5" />
              Speech Bubble Style
            </Label>
            <Select
              value={settings.speechBubbleStyle}
              onValueChange={(v) => updateSetting("speechBubbleStyle", v as ProjectSettings["speechBubbleStyle"])}
            >
              <SelectTrigger className="bg-secondary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="classic">Classic Round</SelectItem>
                <SelectItem value="modern">Modern Sharp</SelectItem>
                <SelectItem value="manga">Manga Style</SelectItem>
                <SelectItem value="retro">Retro Wave</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between py-2">
            <Label className="text-sm flex items-center gap-2">
              <Wand2 className="w-3.5 h-3.5" />
              Auto Scene Detection
            </Label>
            <Switch checked={settings.autoDetectScenes} onCheckedChange={(v) => updateSetting("autoDetectScenes", v)} />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
