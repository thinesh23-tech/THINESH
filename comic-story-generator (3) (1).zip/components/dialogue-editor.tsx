"use client"

import { useState } from "react"
import { X, Plus, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import type { ComicPanel, Dialogue } from "@/lib/types"

interface DialogueEditorProps {
  panel: ComicPanel
  onUpdate: (updates: Partial<ComicPanel>) => void
  onClose: () => void
}

export function DialogueEditor({ panel, onUpdate, onClose }: DialogueEditorProps) {
  const [dialogues, setDialogues] = useState<Dialogue[]>(panel.dialogues)
  const [selectedDialogue, setSelectedDialogue] = useState<string | null>(dialogues.length > 0 ? dialogues[0].id : null)

  const addDialogue = () => {
    const newDialogue: Dialogue = {
      id: `dialogue-${Date.now()}`,
      text: "New dialogue",
      position: { x: 50, y: 30 },
      style: "speech",
    }
    const updated = [...dialogues, newDialogue]
    setDialogues(updated)
    setSelectedDialogue(newDialogue.id)
  }

  const updateDialogue = (id: string, updates: Partial<Dialogue>) => {
    const updated = dialogues.map((d) => (d.id === id ? { ...d, ...updates } : d))
    setDialogues(updated)
  }

  const deleteDialogue = (id: string) => {
    const updated = dialogues.filter((d) => d.id !== id)
    setDialogues(updated)
    setSelectedDialogue(updated.length > 0 ? updated[0].id : null)
  }

  const handleSave = () => {
    onUpdate({ dialogues })
    onClose()
  }

  const selected = dialogues.find((d) => d.id === selectedDialogue)

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <div className="bg-card rounded-xl border border-border w-full max-w-2xl max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h2 className="text-lg font-semibold">Edit Dialogues</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="grid grid-cols-2 divide-x divide-border h-[500px]">
          {/* Preview */}
          <div className="p-4 relative">
            <div className="aspect-[4/3] relative rounded-lg overflow-hidden bg-secondary">
              <img
                src={panel.imageData || "/placeholder.svg"}
                alt="Panel preview"
                className="w-full h-full object-cover"
              />
              {dialogues.map((dialogue) => (
                <div
                  key={dialogue.id}
                  onClick={() => setSelectedDialogue(dialogue.id)}
                  className={`speech-bubble cursor-pointer transition-all ${
                    selectedDialogue === dialogue.id ? "ring-2 ring-primary scale-105" : "hover:scale-102"
                  }`}
                  style={{
                    left: `${dialogue.position.x}%`,
                    top: `${dialogue.position.y}%`,
                    transform: "translate(-50%, -50%)",
                  }}
                >
                  <span className="text-xs font-display">{dialogue.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Controls */}
          <div className="p-4 overflow-y-auto">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Dialogues ({dialogues.length})</Label>
                <Button size="sm" variant="outline" onClick={addDialogue}>
                  <Plus className="w-3 h-3 mr-1" />
                  Add
                </Button>
              </div>

              {/* Dialogue list */}
              <div className="space-y-2">
                {dialogues.map((dialogue) => (
                  <div
                    key={dialogue.id}
                    onClick={() => setSelectedDialogue(dialogue.id)}
                    className={`p-2 rounded-lg cursor-pointer flex items-center justify-between ${
                      selectedDialogue === dialogue.id
                        ? "bg-primary/20 border border-primary"
                        : "bg-secondary hover:bg-secondary/80"
                    }`}
                  >
                    <span className="text-sm truncate flex-1">{dialogue.text}</span>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-6 w-6 shrink-0"
                      onClick={(e) => {
                        e.stopPropagation()
                        deleteDialogue(dialogue.id)
                      }}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>

              {/* Selected dialogue editor */}
              {selected && (
                <div className="space-y-4 pt-4 border-t border-border">
                  <div className="space-y-2">
                    <Label>Text</Label>
                    <Input
                      value={selected.text}
                      onChange={(e) => updateDialogue(selected.id, { text: e.target.value })}
                      className="bg-secondary"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Bubble Style</Label>
                    <Select
                      value={selected.style}
                      onValueChange={(v) => updateDialogue(selected.id, { style: v as Dialogue["style"] })}
                    >
                      <SelectTrigger className="bg-secondary">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="speech">Speech</SelectItem>
                        <SelectItem value="thought">Thought</SelectItem>
                        <SelectItem value="shout">Shout</SelectItem>
                        <SelectItem value="whisper">Whisper</SelectItem>
                        <SelectItem value="narration">Narration</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Position X: {selected.position.x}%</Label>
                    <Slider
                      value={[selected.position.x]}
                      onValueChange={([x]) =>
                        updateDialogue(selected.id, {
                          position: { ...selected.position, x },
                        })
                      }
                      min={10}
                      max={90}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Position Y: {selected.position.y}%</Label>
                    <Slider
                      value={[selected.position.y]}
                      onValueChange={([y]) =>
                        updateDialogue(selected.id, {
                          position: { ...selected.position, y },
                        })
                      }
                      min={10}
                      max={90}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 p-4 border-t border-border">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </div>
      </div>
    </div>
  )
}
