"use client"

import type React from "react"

import { useState } from "react"
import { Palette, Check, Sparkles, Sun, Moon, Zap, Heart, Skull, Wand2 } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import type { ComicStyle } from "@/lib/types"

interface ComicStyleSelectorProps {
  currentStyle: ComicStyle
  onStyleChange: (style: ComicStyle) => void
}

const STYLES: {
  id: ComicStyle
  name: string
  description: string
  icon: React.ReactNode
  preview: string
  colors: string[]
}[] = [
  {
    id: "classic",
    name: "Classic Comics",
    description: "Bold outlines, halftone dots, vibrant colors",
    icon: <Sparkles className="w-4 h-4" />,
    preview: "bg-gradient-to-br from-yellow-400 via-red-500 to-blue-600",
    colors: ["#FFD700", "#FF4444", "#4169E1"],
  },
  {
    id: "manga",
    name: "Manga",
    description: "Japanese style with screentones and speed lines",
    icon: <Heart className="w-4 h-4" />,
    preview: "bg-gradient-to-br from-pink-300 via-white to-gray-200",
    colors: ["#FFB6C1", "#FFFFFF", "#E0E0E0"],
  },
  {
    id: "noir",
    name: "Film Noir",
    description: "High contrast black & white with dramatic shadows",
    icon: <Moon className="w-4 h-4" />,
    preview: "bg-gradient-to-br from-gray-900 via-gray-600 to-white",
    colors: ["#1a1a1a", "#666666", "#FFFFFF"],
  },
  {
    id: "popart",
    name: "Pop Art",
    description: "Andy Warhol inspired, bold primaries, Ben-Day dots",
    icon: <Sun className="w-4 h-4" />,
    preview: "bg-gradient-to-br from-yellow-400 via-pink-500 to-cyan-400",
    colors: ["#FFFF00", "#FF69B4", "#00FFFF"],
  },
  {
    id: "vintage",
    name: "Vintage",
    description: "Aged paper look, muted tones, classic typography",
    icon: <Wand2 className="w-4 h-4" />,
    preview: "bg-gradient-to-br from-amber-200 via-orange-300 to-yellow-100",
    colors: ["#D4A574", "#E8B87A", "#F5DEB3"],
  },
  {
    id: "cyberpunk",
    name: "Cyberpunk",
    description: "Neon colors, glitch effects, futuristic vibes",
    icon: <Zap className="w-4 h-4" />,
    preview: "bg-gradient-to-br from-purple-600 via-pink-500 to-cyan-400",
    colors: ["#8B5CF6", "#EC4899", "#06B6D4"],
  },
  {
    id: "watercolor",
    name: "Watercolor",
    description: "Soft edges, color bleeding, artistic wash",
    icon: <Palette className="w-4 h-4" />,
    preview: "bg-gradient-to-br from-blue-300 via-purple-200 to-pink-300",
    colors: ["#93C5FD", "#DDD6FE", "#F9A8D4"],
  },
  {
    id: "sketch",
    name: "Pencil Sketch",
    description: "Hand-drawn look with crosshatching",
    icon: <Skull className="w-4 h-4" />,
    preview: "bg-gradient-to-br from-gray-300 via-gray-100 to-white",
    colors: ["#9CA3AF", "#F3F4F6", "#FFFFFF"],
  },
]

export function ComicStyleSelector({ currentStyle, onStyleChange }: ComicStyleSelectorProps) {
  const [hoveredStyle, setHoveredStyle] = useState<ComicStyle | null>(null)

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Palette className="w-5 h-5 text-accent" />
          Comic Styles
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-2">
          {STYLES.map((style) => (
            <button
              key={style.id}
              onClick={() => onStyleChange(style.id)}
              onMouseEnter={() => setHoveredStyle(style.id)}
              onMouseLeave={() => setHoveredStyle(null)}
              className={cn(
                "relative p-3 rounded-lg border-2 transition-all duration-200 text-left group",
                currentStyle === style.id
                  ? "border-primary bg-primary/10"
                  : "border-border hover:border-primary/50 bg-secondary/50",
              )}
            >
              <div className="flex items-start gap-2">
                <div className={cn("w-8 h-8 rounded-md flex items-center justify-center", style.preview)}>
                  {style.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{style.name}</p>
                  <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{style.description}</p>
                </div>
              </div>

              {currentStyle === style.id && (
                <div className="absolute top-2 right-2">
                  <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                </div>
              )}

              {/* Color palette preview */}
              <div className="flex gap-1 mt-2">
                {style.colors.map((color, i) => (
                  <div
                    key={i}
                    className="w-4 h-4 rounded-full border border-border/50"
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </button>
          ))}
        </div>

        {hoveredStyle && (
          <div className="mt-3 p-2 rounded-lg bg-muted/50">
            <p className="text-xs text-center text-muted-foreground">
              {STYLES.find((s) => s.id === hoveredStyle)?.description}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
