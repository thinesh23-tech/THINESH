"use client"

import { useState } from "react"
import { X, Sparkles, Zap, Circle, Grid3X3, Wind, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import type { ComicPanel, ComicEffect } from "@/lib/types"

interface EffectsPanelProps {
  panel: ComicPanel
  onUpdate: (updates: Partial<ComicPanel>) => void
  onClose: () => void
}

const AVAILABLE_EFFECTS = [
  { type: "speedlines", name: "Speed Lines", icon: Wind },
  { type: "halftone", name: "Halftone", icon: Grid3X3 },
  { type: "impact", name: "Impact Burst", icon: Zap },
  { type: "sparkle", name: "Sparkles", icon: Sparkles },
  { type: "glow", name: "Glow", icon: Circle },
  { type: "stars", name: "Stars", icon: Star },
] as const

export function EffectsPanel({ panel, onUpdate, onClose }: EffectsPanelProps) {
  const [effects, setEffects] = useState<ComicEffect[]>(panel.effects)

  const toggleEffect = (type: ComicEffect["type"]) => {
    const exists = effects.find((e) => e.type === type)
    if (exists) {
      setEffects(effects.filter((e) => e.type !== type))
    } else {
      setEffects([...effects, { type, intensity: 50 }])
    }
  }

  const updateIntensity = (type: ComicEffect["type"], intensity: number) => {
    setEffects(effects.map((e) => (e.type === type ? { ...e, intensity } : e)))
  }

  const handleSave = () => {
    onUpdate({ effects })
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <div className="bg-card rounded-xl border border-border w-full max-w-md">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Comic Effects
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="p-4 space-y-4">
          {AVAILABLE_EFFECTS.map(({ type, name, icon: Icon }) => {
            const effect = effects.find((e) => e.type === type)
            const isActive = !!effect

            return (
              <div key={type} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        isActive ? "bg-primary/20 text-primary" : "bg-secondary text-muted-foreground"
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <Label className="text-sm font-medium">{name}</Label>
                  </div>
                  <Switch checked={isActive} onCheckedChange={() => toggleEffect(type)} />
                </div>

                {isActive && (
                  <div className="pl-11">
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-muted-foreground w-16">Intensity</span>
                      <Slider
                        value={[effect.intensity]}
                        onValueChange={([v]) => updateIntensity(type, v)}
                        min={10}
                        max={100}
                        className="flex-1"
                      />
                      <span className="text-xs text-muted-foreground w-8">{effect.intensity}%</span>
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>

        <div className="flex items-center justify-end gap-2 p-4 border-t border-border">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Apply Effects</Button>
        </div>
      </div>
    </div>
  )
}
