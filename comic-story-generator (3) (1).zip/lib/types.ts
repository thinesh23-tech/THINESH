export type ComicStyle = "classic" | "manga" | "noir" | "popart" | "vintage" | "cyberpunk" | "watercolor" | "sketch"

export interface Dialogue {
  id: string
  text: string
  position: { x: number; y: number }
  style: "speech" | "thought" | "shout" | "whisper" | "narration"
  character?: string
  emotion?: "neutral" | "happy" | "angry" | "sad" | "excited" | "scared"
}

export interface ComicEffect {
  type: "speedlines" | "halftone" | "impact" | "sparkle" | "glow" | "stars"
  intensity: number
}

export interface ComicPanel {
  id: string
  imageData: string
  timestamp: number
  style: ComicStyle
  dialogues: Dialogue[]
  effects: ComicEffect[]
}

export interface ProjectSettings {
  panelLayout: "grid" | "strip" | "manga"
  autoDetectScenes: boolean
  speechBubbleStyle: "classic" | "modern" | "manga" | "retro"
  exportQuality: "standard" | "high" | "print"
  pageSize: "a4" | "letter" | "comic"
}

export interface ExportOptions {
  format: "pdf" | "png" | "gif"
  quality: "standard" | "high" | "print"
  includeDialogues: boolean
  includeCover: boolean
}

export interface CharacterProfile {
  id: string
  name: string
  color: string
  defaultBubbleStyle: "speech" | "thought" | "shout" | "whisper" | "narration"
}
