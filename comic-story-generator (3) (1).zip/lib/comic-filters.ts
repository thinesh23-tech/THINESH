import type { ComicStyle } from "./types"

export function applyComicFilter(canvas: HTMLCanvasElement, style: ComicStyle): HTMLCanvasElement {
  const ctx = canvas.getContext("2d")
  if (!ctx) return canvas

  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
  const data = imageData.data

  switch (style) {
    case "classic":
      applyClassicFilter(data)
      break
    case "manga":
      applyMangaFilter(data)
      break
    case "noir":
      applyNoirFilter(data)
      break
    case "popart":
      applyPopArtFilter(data)
      break
    case "vintage":
      applyVintageFilter(data)
      break
    case "cyberpunk":
      applyCyberpunkFilter(data)
      break
    case "watercolor":
      applyWatercolorFilter(data)
      break
    case "sketch":
      applySketchFilter(data)
      break
  }

  ctx.putImageData(imageData, 0, 0)

  // Apply edge detection for comic outline effect
  applyEdgeEnhancement(ctx, canvas.width, canvas.height, style)

  return canvas
}

function applyClassicFilter(data: Uint8ClampedArray) {
  for (let i = 0; i < data.length; i += 4) {
    // Increase contrast and saturation
    const r = data[i]
    const g = data[i + 1]
    const b = data[i + 2]

    // Posterize to fewer colors
    const levels = 6
    data[i] = Math.round(r / (256 / levels)) * (256 / levels)
    data[i + 1] = Math.round(g / (256 / levels)) * (256 / levels)
    data[i + 2] = Math.round(b / (256 / levels)) * (256 / levels)

    // Boost saturation
    const avg = (data[i] + data[i + 1] + data[i + 2]) / 3
    const satBoost = 1.4
    data[i] = Math.min(255, avg + (data[i] - avg) * satBoost)
    data[i + 1] = Math.min(255, avg + (data[i + 1] - avg) * satBoost)
    data[i + 2] = Math.min(255, avg + (data[i + 2] - avg) * satBoost)
  }
}

function applyMangaFilter(data: Uint8ClampedArray) {
  for (let i = 0; i < data.length; i += 4) {
    // Convert to grayscale with high contrast
    const gray = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114

    // Apply screentone effect (simulated)
    let value = gray
    if (gray < 80) value = 0
    else if (gray < 160) value = gray * 0.6
    else value = 255

    data[i] = value
    data[i + 1] = value
    data[i + 2] = value
  }
}

function applyNoirFilter(data: Uint8ClampedArray) {
  for (let i = 0; i < data.length; i += 4) {
    // High contrast black and white
    const gray = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114

    // Strong threshold for dramatic shadows
    const contrast = 1.8
    let value = ((gray / 255 - 0.5) * contrast + 0.5) * 255
    value = Math.max(0, Math.min(255, value))

    // Threshold to pure black or white
    if (value < 100) value = 0
    else if (value > 200) value = 255

    data[i] = value
    data[i + 1] = value
    data[i + 2] = value
  }
}

function applyPopArtFilter(data: Uint8ClampedArray) {
  const colors = [
    [255, 0, 255], // Magenta
    [0, 255, 255], // Cyan
    [255, 255, 0], // Yellow
    [255, 0, 0], // Red
    [0, 0, 255], // Blue
    [255, 255, 255], // White
    [0, 0, 0], // Black
  ]

  for (let i = 0; i < data.length; i += 4) {
    // Find closest pop art color
    let minDist = Number.POSITIVE_INFINITY
    let closest = [0, 0, 0]

    for (const color of colors) {
      const dist = Math.sqrt(
        Math.pow(data[i] - color[0], 2) + Math.pow(data[i + 1] - color[1], 2) + Math.pow(data[i + 2] - color[2], 2),
      )
      if (dist < minDist) {
        minDist = dist
        closest = color
      }
    }

    data[i] = closest[0]
    data[i + 1] = closest[1]
    data[i + 2] = closest[2]
  }
}

function applyVintageFilter(data: Uint8ClampedArray) {
  for (let i = 0; i < data.length; i += 4) {
    // Sepia tone with faded look
    const r = data[i]
    const g = data[i + 1]
    const b = data[i + 2]

    data[i] = Math.min(255, r * 0.9 + g * 0.3 + b * 0.1 + 30)
    data[i + 1] = Math.min(255, r * 0.6 + g * 0.5 + b * 0.1 + 20)
    data[i + 2] = Math.min(255, r * 0.4 + g * 0.3 + b * 0.2 + 10)

    // Add slight fade
    data[i] = Math.min(255, data[i] * 0.9 + 25)
    data[i + 1] = Math.min(255, data[i + 1] * 0.9 + 20)
    data[i + 2] = Math.min(255, data[i + 2] * 0.9 + 15)
  }
}

function applyCyberpunkFilter(data: Uint8ClampedArray) {
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i]
    const g = data[i + 1]
    const b = data[i + 2]

    // Shift towards cyan and magenta
    const intensity = (r + g + b) / 3

    if (intensity < 128) {
      // Dark areas get magenta/purple tint
      data[i] = Math.min(255, r * 0.8 + 60)
      data[i + 1] = Math.min(255, g * 0.3)
      data[i + 2] = Math.min(255, b * 0.8 + 80)
    } else {
      // Light areas get cyan tint
      data[i] = Math.min(255, r * 0.3)
      data[i + 1] = Math.min(255, g * 0.9 + 50)
      data[i + 2] = Math.min(255, b * 0.9 + 80)
    }

    // Increase contrast
    const contrast = 1.3
    data[i] = Math.min(255, Math.max(0, ((data[i] / 255 - 0.5) * contrast + 0.5) * 255))
    data[i + 1] = Math.min(255, Math.max(0, ((data[i + 1] / 255 - 0.5) * contrast + 0.5) * 255))
    data[i + 2] = Math.min(255, Math.max(0, ((data[i + 2] / 255 - 0.5) * contrast + 0.5) * 255))
  }
}

function applyWatercolorFilter(data: Uint8ClampedArray) {
  for (let i = 0; i < data.length; i += 4) {
    // Soft, pastel colors
    const r = data[i]
    const g = data[i + 1]
    const b = data[i + 2]

    // Reduce saturation and add white
    const avg = (r + g + b) / 3
    const saturation = 0.5

    data[i] = Math.min(255, avg + (r - avg) * saturation + 40)
    data[i + 1] = Math.min(255, avg + (g - avg) * saturation + 40)
    data[i + 2] = Math.min(255, avg + (b - avg) * saturation + 40)

    // Soften edges by reducing contrast slightly
    data[i] = Math.min(255, data[i] * 0.85 + 38)
    data[i + 1] = Math.min(255, data[i + 1] * 0.85 + 38)
    data[i + 2] = Math.min(255, data[i + 2] * 0.85 + 38)
  }
}

function applySketchFilter(data: Uint8ClampedArray) {
  for (let i = 0; i < data.length; i += 4) {
    // Convert to grayscale pencil sketch look
    const gray = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114

    // Invert and blend for sketch effect
    const inverted = 255 - gray
    const sketched = gray + inverted * 0.3

    // Add paper texture (slight warmth)
    data[i] = Math.min(255, sketched + 5)
    data[i + 1] = Math.min(255, sketched + 3)
    data[i + 2] = Math.min(255, sketched)
  }
}

function applyEdgeEnhancement(ctx: CanvasRenderingContext2D, width: number, height: number, style: ComicStyle) {
  // Get image data for edge detection
  const imageData = ctx.getImageData(0, 0, width, height)
  const data = imageData.data
  const edges = new Uint8ClampedArray(data.length)

  // Sobel edge detection
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const idx = (y * width + x) * 4

      // Get surrounding pixels (grayscale)
      const getGray = (ox: number, oy: number) => {
        const i = ((y + oy) * width + (x + ox)) * 4
        return data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114
      }

      // Sobel kernels
      const gx =
        -getGray(-1, -1) + getGray(1, -1) + -2 * getGray(-1, 0) + 2 * getGray(1, 0) + -getGray(-1, 1) + getGray(1, 1)

      const gy =
        -getGray(-1, -1) - 2 * getGray(0, -1) - getGray(1, -1) + getGray(-1, 1) + 2 * getGray(0, 1) + getGray(1, 1)

      const magnitude = Math.sqrt(gx * gx + gy * gy)
      const edgeStrength = style === "manga" || style === "noir" ? 0.8 : 0.5
      const threshold = style === "sketch" ? 30 : 50

      if (magnitude > threshold) {
        edges[idx] = 0
        edges[idx + 1] = 0
        edges[idx + 2] = 0
        edges[idx + 3] = Math.min(255, magnitude * edgeStrength)
      } else {
        edges[idx + 3] = 0
      }
    }
  }

  // Blend edges with original
  for (let i = 0; i < data.length; i += 4) {
    if (edges[i + 3] > 0) {
      const alpha = edges[i + 3] / 255
      data[i] = data[i] * (1 - alpha) + edges[i] * alpha
      data[i + 1] = data[i + 1] * (1 - alpha) + edges[i + 1] * alpha
      data[i + 2] = data[i + 2] * (1 - alpha) + edges[i + 2] * alpha
    }
  }

  ctx.putImageData(imageData, 0, 0)
}

export function addHalftoneEffect(canvas: HTMLCanvasElement, dotSize = 4): HTMLCanvasElement {
  const ctx = canvas.getContext("2d")
  if (!ctx) return canvas

  const width = canvas.width
  const height = canvas.height
  const imageData = ctx.getImageData(0, 0, width, height)

  // Clear and redraw with halftone
  ctx.fillStyle = "white"
  ctx.fillRect(0, 0, width, height)
  ctx.fillStyle = "black"

  for (let y = 0; y < height; y += dotSize * 2) {
    for (let x = 0; x < width; x += dotSize * 2) {
      const idx = (y * width + x) * 4
      const brightness = (imageData.data[idx] + imageData.data[idx + 1] + imageData.data[idx + 2]) / 3
      const radius = (1 - brightness / 255) * dotSize

      ctx.beginPath()
      ctx.arc(x + dotSize, y + dotSize, radius, 0, Math.PI * 2)
      ctx.fill()
    }
  }

  return canvas
}
