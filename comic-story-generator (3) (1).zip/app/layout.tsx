import type React from "react"
import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Bangers } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })
const _bangers = Bangers({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-display",
})

export const metadata: Metadata = {
  title: "ComicForge AI - Real-Time Comic Story Generator",
  description:
    "Transform videos into stunning comic stories with AI-powered scene detection, multiple art styles, and voice-to-dialogue transcription. Create manga, noir, pop art, and more!",
  keywords: ["comic generator", "AI comics", "video to comic", "manga creator", "speech bubbles", "comic maker"],
  authors: [{ name: "ComicForge AI" }],
  openGraph: {
    title: "ComicForge AI - Real-Time Comic Story Generator",
    description: "Transform videos into stunning comic stories with AI",
    type: "website",
  },
    generator: 'v0.app'
}

export const viewport: Viewport = {
  themeColor: "#0891b2",
  width: "device-width",
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`font-sans antialiased ${_bangers.variable}`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
