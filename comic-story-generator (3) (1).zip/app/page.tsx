import { ComicStudioApp } from "@/components/comic-studio-app"

export default function Home() {
  return <ComicStudioApp />
}
