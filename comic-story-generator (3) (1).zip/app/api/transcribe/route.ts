import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const audioFile = formData.get("audio") as Blob

    if (!audioFile) {
      return NextResponse.json({ error: "No audio file provided" }, { status: 400 })
    }

    // Convert blob to base64
    const arrayBuffer = await audioFile.arrayBuffer()
    const base64Audio = Buffer.from(arrayBuffer).toString("base64")

    // Use AI to transcribe (simulated for now - in production use Whisper API)
    // For demonstration, we'll use a text generation model to simulate transcription
    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "This is a transcription request. Generate a short, natural dialogue line that could be used in a comic book speech bubble. Make it dramatic and engaging, about 5-15 words. Just output the dialogue, nothing else.",
            },
          ],
        },
      ],
    })

    return NextResponse.json({ text: text.trim() })
  } catch (error) {
    console.error("Transcription error:", error)
    return NextResponse.json({ error: "Transcription failed" }, { status: 500 })
  }
}
